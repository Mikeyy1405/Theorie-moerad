
import { StudentDashboard } from '@/components/student/student-dashboard'

export default function DashboardPage() {
  return <StudentDashboard />
}
